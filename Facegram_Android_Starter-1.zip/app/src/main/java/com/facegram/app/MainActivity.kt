package com.facegram.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.navigation.compose.*

private val Blue = Color(0xFF246BFD)
private val Ink = Color(0xFF17243A)
private val Muted = Color(0xFF7B8798)
private val Bg = Color(0xFFF4F7FC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FacegramApp() }
    }
}

@Composable
fun FacegramApp() {
    val nav = rememberNavController()
    val tabs = listOf("Home", "Reels", "Chat", "Profile")
    val icons = listOf(Icons.Default.Home, Icons.Default.PlayCircle, Icons.Default.ChatBubble, Icons.Default.Person)
    var selected by remember { mutableStateOf("Home") }
    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, background = Bg)) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    tabs.forEachIndexed { i, tab ->
                        NavigationBarItem(
                            selected = selected == tab,
                            onClick = { selected = tab; nav.navigate(tab) { launchSingleTop = true } },
                            icon = { Icon(icons[i], null) },
                            label = { Text(tab, fontSize = 11.sp) }
                        )
                    }
                }
            }
        ) { padding ->
            NavHost(navController = nav, startDestination = "Home", modifier = Modifier.padding(padding)) {
                composable("Home") { HomeScreen(onChat = { selected = "Chat"; nav.navigate("Chat") }) }
                composable("Reels") { ReelsScreen() }
                composable("Chat") { ChatScreen() }
                composable("Profile") { ProfileScreen() }
            }
        }
    }
}

@Composable
fun Header() {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("face", color = Ink, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
        Text("gram", color = Blue, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.weight(1f))
        IconButton(onClick = {}) { Icon(Icons.Default.NotificationsNone, "Notifications", tint = Ink) }
        IconButton(onClick = {}) { Icon(Icons.Default.AddCircleOutline, "Create post", tint = Ink) }
    }
}

@Composable
fun Avatar(name: String, color: Color = Blue, size: Int = 48, ring: Boolean = false) {
    Box(
        Modifier.size(size.dp).clip(CircleShape)
            .background(if (ring) Brush.linearGradient(listOf(Color(0xFFFF7A59), Color(0xFF8A4DFF))) else Brush.linearGradient(listOf(color, color.copy(alpha=.65f))))
            .padding(if (ring) 3.dp else 0.dp).clip(CircleShape).background(Color.White),
        contentAlignment = Alignment.Center
    ) {
        Text(name.take(1).uppercase(), color = color, fontWeight = FontWeight.Bold, fontSize = (size/2.6).sp)
    }
}

@Composable
fun HomeScreen(onChat: () -> Unit) {
    var liked by remember { mutableStateOf(setOf<Int>()) }
    val names = listOf("Alya Putri", "Rizky Pratama", "Nadia Zahra")
    LazyColumn(contentPadding = PaddingValues(bottom = 18.dp)) {
        item { Header() }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Stories", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Ink)
                Spacer(Modifier.weight(1f))
                Text("Lihat semua", color = Blue, fontSize = 12.sp)
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 12.dp)) {
                Spacer(Modifier.width(14.dp))
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(end = 14.dp)) {
                    Box {
                        Avatar("K", Blue, 58)
                        Icon(Icons.Default.AddCircle, null, tint = Blue, modifier = Modifier.align(Alignment.BottomEnd).size(20.dp).background(Color.White, CircleShape))
                    }
                    Text("Cerita kamu", fontSize = 11.sp, color = Muted)
                }
                names.forEachIndexed { i, name ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(end = 14.dp)) {
                        Avatar(name, listOf(Color(0xFFEC7B61), Color(0xFF7B61D1), Color(0xFF19A78B))[i], 58, true)
                        Text(name.substringBefore(" "), fontSize = 11.sp, color = Ink)
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar("K", size = 40)
                    Spacer(Modifier.width(10.dp))
                    Text("Apa yang sedang kamu pikirkan?", color = Muted, modifier = Modifier.weight(1f), fontSize = 13.sp)
                    Icon(Icons.Default.Image, null, tint = Color(0xFF25A66A))
                }
            }
        }
        items(names.indices.toList()) { i ->
            Card(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 7.dp), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                Column {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(names[i], listOf(Color(0xFFEC7B61), Color(0xFF7B61D1), Color(0xFF19A78B))[i], 42)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(names[i], color = Ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("2 jam lalu · 🌐 Publik", color = Muted, fontSize = 11.sp)
                        }
                        Icon(Icons.Default.MoreHoriz, null, tint = Muted)
                    }
                    Text(
                        listOf("Hari yang menyenangkan! Senang bisa berbagi momen di Facegram ✨", "Menikmati waktu santai hari ini. Semoga harimu menyenangkan!", "Small moments, big memories 💙")[i],
                        Modifier.padding(horizontal = 14.dp, vertical = 4.dp), color = Ink, fontSize = 13.sp
                    )
                    Box(Modifier.fillMaxWidth().height(205.dp).padding(12.dp).clip(RoundedCornerShape(14.dp)).background(
                        Brush.linearGradient(listOf(listOf(Color(0xFFB7D8FF), Color(0xFF647FEA)), listOf(Color(0xFFFFD4B8), Color(0xFFDE7892)), listOf(Color(0xFFB8E7D8), Color(0xFF3D9B91))[i]))
                    ), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Landscape, null, tint = Color.White.copy(alpha=.9f), modifier = Modifier.size(64.dp))
                    }
                    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${(128-i*31)} suka  ·  ${12-i} komentar", color = Muted, fontSize = 11.sp)
                        Spacer(Modifier.weight(1f))
                        Text("Bagikan", color = Muted, fontSize = 11.sp)
                    }
                    HorizontalDivider(color = Bg)
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                        TextButton(onClick = { liked = if (i in liked) liked - i else liked + i }) {
                            Icon(Icons.Default.Favorite, null, tint = if (i in liked) Color(0xFFE64B68) else Muted, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(5.dp)); Text(if (i in liked) "Disukai" else "Suka", color = if (i in liked) Color(0xFFE64B68) else Muted)
                        }
                        TextButton(onClick = {}) { Icon(Icons.Default.ModeComment, null, tint = Muted); Spacer(Modifier.width(5.dp)); Text("Komentar", color = Muted) }
                        TextButton(onClick = onChat) { Icon(Icons.Default.Send, null, tint = Muted); Spacer(Modifier.width(5.dp)); Text("Kirim", color = Muted) }
                    }
                }
            }
        }
    }
}

@Composable
fun ReelsScreen() {
    var liked by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize().background(Color(0xFF111827))) {
        Box(Modifier.fillMaxSize().padding(14.dp).clip(RoundedCornerShape(22.dp)).background(Brush.linearGradient(listOf(Color(0xFF2E4776), Color(0xFF9B5D83), Color(0xFFDE9A70)))), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.PlayCircle, null, tint = Color.White, modifier = Modifier.size(78.dp))
                Text("Reels Facegram", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Video pendek akan tampil di sini", color = Color.White.copy(alpha=.8f), fontSize = 12.sp)
            }
        }
        Column(Modifier.align(Alignment.BottomEnd).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            IconButton(onClick = { liked = !liked }) { Icon(Icons.Default.Favorite, null, tint = if (liked) Color.Red else Color.White, modifier = Modifier.size(30.dp)) }
            Text(if (liked) "Disukai" else "Suka", color = Color.White, fontSize = 11.sp)
            Spacer(Modifier.height(12.dp))
            Icon(Icons.Default.ModeComment, null, tint = Color.White)
            Text("Komentar", color = Color.White, fontSize = 11.sp)
            Spacer(Modifier.height(12.dp))
            Icon(Icons.Default.Send, null, tint = Color.White)
            Text("Bagikan", color = Color.White, fontSize = 11.sp)
        }
        Text("Untukmu", Modifier.align(Alignment.TopStart).padding(28.dp), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun ChatScreen() {
    val people = listOf("Alya Putri", "Rizky Pratama", "Nadia Zahra", "Dimas Saputra")
    Column(Modifier.fillMaxSize()) {
        Header()
        Text("Pesan", Modifier.padding(horizontal = 18.dp, vertical = 6.dp), fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Ink)
        OutlinedTextField(value = "", onValueChange = {}, enabled = false, placeholder = { Text("Cari percakapan") }, leadingIcon = { Icon(Icons.Default.Search, null) }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp), shape = RoundedCornerShape(16.dp))
        people.forEachIndexed { i, person ->
            Row(Modifier.fillMaxWidth().clickable { }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Avatar(person, size = 48)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(person, color = Ink, fontWeight = FontWeight.Bold)
                    Text(listOf("Hai! Apa kabar?", "Video yang tadi keren!", "Sampai ketemu nanti", "Oke, siap!")[i], color = Muted, fontSize = 12.sp)
                }
                Text("${i+1}j", color = Muted, fontSize = 10.sp)
            }
            HorizontalDivider(color = Color(0xFFE9EDF4))
        }
    }
}

@Composable
fun ProfileScreen() {
    var following by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header()
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Avatar("K", Blue, 82)
            Spacer(Modifier.width(24.dp))
            Column {
                Text("0", fontWeight = FontWeight.Bold, fontSize = 19.sp, color = Ink)
                Text("Postingan", color = Muted, fontSize = 12.sp)
            }
            Spacer(Modifier.width(20.dp))
            Column {
                Text("128", fontWeight = FontWeight.Bold, fontSize = 19.sp, color = Ink)
                Text("Pengikut", color = Muted, fontSize = 12.sp)
            }
            Spacer(Modifier.width(20.dp))
            Column {
                Text("96", fontWeight = FontWeight.Bold, fontSize = 19.sp, color = Ink)
                Text("Mengikuti", color = Muted, fontSize = 12.sp)
            }
        }
        Text("Pengguna Facegram", Modifier.padding(horizontal = 18.dp), color = Ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Text("Berbagi cerita, foto, dan momen terbaik ✨", Modifier.padding(horizontal = 18.dp, vertical = 5.dp), color = Muted, fontSize = 13.sp)
        Row(Modifier.fillMaxWidth().padding(18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { following = !following }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)) { Text(if (following) "Mengikuti" else "Edit profil") }
            OutlinedButton(onClick = {}, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)) { Text("Bagikan profil") }
        }
        HorizontalDivider(color = Color(0xFFE9EDF4))
        Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.GridOn, null, tint = Muted, modifier = Modifier.size(36.dp))
                Spacer(Modifier.height(8.dp))
                Text("Postingan kamu akan muncul di sini", color = Muted, fontSize = 12.sp)
            }
        }
    }
}
