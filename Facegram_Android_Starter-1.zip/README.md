# Facegram — Android starter

Facegram is a modern social-media UI prototype: Facebook-inspired navigation and layout with Instagram-style Stories, feed, Reels, likes, chat list, and profile.

## Open in Android Studio
1. Install Android Studio (with Android SDK 35).
2. Choose **Open** and select this `Facegram` folder.
3. Wait for Gradle sync.
4. Run on an Android emulator or connected Android device.
5. To create an APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Current prototype scope
- Interactive bottom navigation: Home, Reels, Chat, Profile.
- Story row and sample social feed.
- Like toggle on feed and Reels.
- Sample chat list and profile screen.
- Modern blue/white visual system.

## Not connected yet
This is a front-end prototype. Real accounts, authentication, media upload, cloud storage, live chat, notifications, follow graph, and server-backed comments require a backend (for example Firebase) and additional implementation. The sample content is local demo content.
